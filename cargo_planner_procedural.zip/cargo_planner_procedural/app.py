from cargo_planner_procedural import user_input_choice  

user_input_choice()